"""Bundled static assets.

This package contains files we want available at runtime even when the
Snowfakery git submodule is not present (e.g. when installed from a wheel).
"""
